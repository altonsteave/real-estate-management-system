from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from flask_mysqldb import MySQL
import os
import hashlib
from werkzeug.utils import secure_filename
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'elite_estates_secret_key_2026'

# MySQL Configuration (XAMPP)
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''  # Default XAMPP has no password
app.config['MYSQL_DB'] = 'elite_estates'
app.config['MYSQL_CURSORCLASS'] = 'DictCursor'

mysql = MySQL(app)

UPLOAD_FOLDER = os.path.join('static', 'uploads')
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'webp'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

# ─── HOME ────────────────────────────────────────────────────────────────────
@app.route('/')
def index():
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM properties WHERE status='approved' ORDER BY created_at DESC LIMIT 6")
    featured = cur.fetchall()
    cur.close()
    return render_template('index.html', featured=featured)

# ─── AUTH ────────────────────────────────────────────────────────────────────
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        phone = request.form['phone']
        password = hash_password(request.form['password'])
        role = request.form.get('role', 'user')

        cur = mysql.connection.cursor()
        cur.execute("SELECT id FROM users WHERE email=%s", (email,))
        existing = cur.fetchone()
        if existing:
            flash('Email already registered.', 'error')
            return redirect(url_for('register'))

        cur.execute(
            "INSERT INTO users (name, email, phone, password, role) VALUES (%s,%s,%s,%s,%s)",
            (name, email, phone, password, role)
        )
        mysql.connection.commit()
        cur.close()
        flash('Registration successful! Please login.', 'success')
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = hash_password(request.form['password'])
        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM users WHERE email=%s AND password=%s", (email, password))
        user = cur.fetchone()
        cur.close()
        if user:
            session['user_id'] = user['id']
            session['user_name'] = user['name']
            session['user_role'] = user['role']
            if user['role'] == 'admin':
                return redirect(url_for('admin_dashboard'))
            return redirect(url_for('user_dashboard'))
        flash('Invalid credentials.', 'error')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

# ─── USER DASHBOARD ──────────────────────────────────────────────────────────
@app.route('/dashboard')
def user_dashboard():
    if 'user_id' not in session or session['user_role'] != 'user':
        return redirect(url_for('login'))
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM properties WHERE user_id=%s ORDER BY created_at DESC", (session['user_id'],))
    my_props = cur.fetchall()
    cur.execute("SELECT b.*, p.title, p.price FROM bookings b JOIN properties p ON b.property_id=p.id WHERE b.user_id=%s ORDER BY b.created_at DESC", (session['user_id'],))
    my_bookings = cur.fetchall()
    cur.close()
    return render_template('user_dashboard.html', properties=my_props, bookings=my_bookings)

# ─── PROPERTIES ──────────────────────────────────────────────────────────────
@app.route('/properties')
def properties():
    prop_type = request.args.get('type', '')
    search = request.args.get('search', '')
    cur = mysql.connection.cursor()
    query = "SELECT p.*, u.name as owner_name FROM properties p JOIN users u ON p.user_id=u.id WHERE p.status='approved'"
    params = []
    if prop_type:
        query += " AND p.type=%s"
        params.append(prop_type)
    if search:
        query += " AND (p.title LIKE %s OR p.location LIKE %s)"
        params.extend([f'%{search}%', f'%{search}%'])
    query += " ORDER BY p.created_at DESC"
    cur.execute(query, params)
    props = cur.fetchall()
    cur.close()
    return render_template('properties.html', properties=props, prop_type=prop_type, search=search)

@app.route('/property/<int:pid>')
def property_detail(pid):
    cur = mysql.connection.cursor()
    cur.execute("SELECT p.*, u.name as owner_name, u.phone as owner_phone FROM properties p JOIN users u ON p.user_id=u.id WHERE p.id=%s", (pid,))
    prop = cur.fetchone()
    cur.close()
    if not prop:
        flash('Property not found.', 'error')
        return redirect(url_for('properties'))
    return render_template('property_detail.html', prop=prop)

@app.route('/add-property', methods=['GET', 'POST'])
def add_property():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    if request.method == 'POST':
        title = request.form['title']
        description = request.form['description']
        price = request.form['price']
        location = request.form['location']
        prop_type = request.form['type']
        bedrooms = request.form.get('bedrooms', 0)
        bathrooms = request.form.get('bathrooms', 0)
        area = request.form.get('area', 0)
        auction_end = request.form.get('auction_end', None)

        image_filename = None
        if 'image' in request.files:
            file = request.files['image']
            if file and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
                image_filename = f"{timestamp}_{filename}"
                file.save(os.path.join(app.config['UPLOAD_FOLDER'], image_filename))

        cur = mysql.connection.cursor()
        cur.execute(
            """INSERT INTO properties 
            (user_id, title, description, price, location, type, bedrooms, bathrooms, area, image, auction_end, status)
            VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,'pending')""",
            (session['user_id'], title, description, price, location, prop_type,
             bedrooms, bathrooms, area, image_filename, auction_end if auction_end else None)
        )
        mysql.connection.commit()
        cur.close()
        flash('Property submitted for approval!', 'success')
        return redirect(url_for('user_dashboard'))
    return render_template('add_property.html')

# ─── BOOKING / PAYMENT ───────────────────────────────────────────────────────
@app.route('/book/<int:pid>', methods=['GET', 'POST'])
def book_property(pid):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM properties WHERE id=%s AND status='approved'", (pid,))
    prop = cur.fetchone()
    if not prop:
        flash('Property not available.', 'error')
        return redirect(url_for('properties'))
    if request.method == 'POST':
        advance = float(prop['price']) * 0.10
        cur.execute(
            "INSERT INTO bookings (user_id, property_id, advance_amount, appointment_date, status) VALUES (%s,%s,%s,%s,'pending')",
            (session['user_id'], pid, advance, request.form.get('appointment_date'))
        )
        mysql.connection.commit()
        cur.close()
        flash(f'Booking confirmed! Advance of ₹{advance:,.0f} is due.', 'success')
        return redirect(url_for('user_dashboard'))
    cur.close()
    return render_template('book_property.html', prop=prop)

# ─── AUCTIONS ────────────────────────────────────────────────────────────────
@app.route('/auctions')
def auctions():
    cur = mysql.connection.cursor()
    cur.execute("SELECT p.*, u.name as owner_name, MAX(b.amount) as current_bid FROM properties p JOIN users u ON p.user_id=u.id LEFT JOIN bids b ON p.id=b.property_id WHERE p.type='auction' AND p.status='approved' GROUP BY p.id ORDER BY p.auction_end ASC")
    auctions = cur.fetchall()
    cur.close()
    return render_template('auctions.html', auctions=auctions)

@app.route('/bid/<int:pid>', methods=['POST'])
def place_bid(pid):
    if 'user_id' not in session:
        return jsonify({'error': 'Login required'}), 401
    amount = float(request.form['amount'])
    cur = mysql.connection.cursor()
    cur.execute("SELECT MAX(amount) as top FROM bids WHERE property_id=%s", (pid,))
    top = cur.fetchone()
    cur.execute("SELECT price FROM properties WHERE id=%s", (pid,))
    prop = cur.fetchone()
    min_bid = float(top['top']) if top['top'] else float(prop['price'])
    if amount <= min_bid:
        flash(f'Bid must be higher than ₹{min_bid:,.0f}', 'error')
        return redirect(url_for('auctions'))
    cur.execute("INSERT INTO bids (user_id, property_id, amount) VALUES (%s,%s,%s)", (session['user_id'], pid, amount))
    mysql.connection.commit()
    cur.close()
    flash('Bid placed successfully!', 'success')
    return redirect(url_for('auctions'))

# ─── ADMIN ───────────────────────────────────────────────────────────────────
@app.route('/admin')
def admin_dashboard():
    if 'user_id' not in session or session['user_role'] != 'admin':
        return redirect(url_for('login'))
    cur = mysql.connection.cursor()
    cur.execute("SELECT COUNT(*) as c FROM users WHERE role='user'")
    users_count = cur.fetchone()['c']
    cur.execute("SELECT COUNT(*) as c FROM properties")
    props_count = cur.fetchone()['c']
    cur.execute("SELECT COUNT(*) as c FROM properties WHERE status='pending'")
    pending_count = cur.fetchone()['c']
    cur.execute("SELECT COUNT(*) as c FROM bookings")
    bookings_count = cur.fetchone()['c']
    cur.execute("SELECT p.*, u.name as owner_name FROM properties p JOIN users u ON p.user_id=u.id WHERE p.status='pending' ORDER BY p.created_at DESC")
    pending_props = cur.fetchall()
    cur.execute("SELECT * FROM users WHERE role='user' ORDER BY created_at DESC")
    all_users = cur.fetchall()
    cur.execute("SELECT p.*, u.name as owner_name FROM properties p JOIN users u ON p.user_id=u.id ORDER BY p.created_at DESC")
    all_props = cur.fetchall()
    cur.close()
    return render_template('admin_dashboard.html',
        users_count=users_count, props_count=props_count,
        pending_count=pending_count, bookings_count=bookings_count,
        pending_props=pending_props, all_users=all_users, all_props=all_props)

@app.route('/admin/approve/<int:pid>')
def approve_property(pid):
    if session.get('user_role') != 'admin':
        return redirect(url_for('login'))
    cur = mysql.connection.cursor()
    cur.execute("UPDATE properties SET status='approved' WHERE id=%s", (pid,))
    mysql.connection.commit()
    cur.close()
    flash('Property approved!', 'success')
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/reject/<int:pid>')
def reject_property(pid):
    if session.get('user_role') != 'admin':
        return redirect(url_for('login'))
    cur = mysql.connection.cursor()
    cur.execute("UPDATE properties SET status='rejected' WHERE id=%s", (pid,))
    mysql.connection.commit()
    cur.close()
    flash('Property rejected.', 'error')
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/delete-user/<int:uid>')
def delete_user(uid):
    if session.get('user_role') != 'admin':
        return redirect(url_for('login'))
    cur = mysql.connection.cursor()
    cur.execute("DELETE FROM users WHERE id=%s AND role='user'", (uid,))
    mysql.connection.commit()
    cur.close()
    flash('User deleted.', 'success')
    return redirect(url_for('admin_dashboard'))

if __name__ == '__main__':
    app.run(debug=True)
