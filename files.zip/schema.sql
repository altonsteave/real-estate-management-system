-- ============================================================
-- Elite Estates - Real Estate Management System
-- Import this file in phpMyAdmin or run via MySQL CLI
-- ============================================================

CREATE DATABASE IF NOT EXISTS elite_estates CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE elite_estates;

-- Users Table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) UNIQUE NOT NULL,
    phone VARCHAR(20),
    password VARCHAR(256) NOT NULL,
    role ENUM('user','admin') DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Properties Table
CREATE TABLE IF NOT EXISTS properties (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    price DECIMAL(15,2) NOT NULL,
    location VARCHAR(200),
    type ENUM('sale','rent','auction') NOT NULL,
    bedrooms INT DEFAULT 0,
    bathrooms INT DEFAULT 0,
    area DECIMAL(10,2) DEFAULT 0,
    image VARCHAR(300),
    auction_end DATETIME,
    status ENUM('pending','approved','rejected','sold') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Bookings Table
CREATE TABLE IF NOT EXISTS bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    property_id INT NOT NULL,
    advance_amount DECIMAL(15,2),
    appointment_date DATE,
    status ENUM('pending','confirmed','cancelled') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (property_id) REFERENCES properties(id) ON DELETE CASCADE
);

-- Bids Table (for Auctions)
CREATE TABLE IF NOT EXISTS bids (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    property_id INT NOT NULL,
    amount DECIMAL(15,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (property_id) REFERENCES properties(id) ON DELETE CASCADE
);

-- ─── Default Admin Account ────────────────────────────────────────────────
-- Password: admin123 (SHA256 hashed)
INSERT INTO users (name, email, phone, password, role) VALUES
('Administrator', 'admin@eliteestates.com', '9876543210',
 '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9', 'admin');

-- ─── Sample Properties (optional demo data) ──────────────────────────────
-- You can remove these if you want a clean start
INSERT INTO users (name, email, phone, password, role) VALUES
('Demo User', 'user@demo.com', '9999999999',
 'ef92b778bafe771e89245b89ecbc08a44a4e166c06659911881f383d4473e94f', 'user');
-- Demo user password: password123

INSERT INTO properties (user_id, title, description, price, location, type, bedrooms, bathrooms, area, image, status) VALUES
(2, 'Elegant Sea-View Villa', 'Breathtaking ocean views, private pool, modern architecture with heritage touches.', 25000000, 'Kovalam, Kerala', 'sale', 4, 3, 3500, NULL, 'approved'),
(2, 'Heritage Bungalow', 'Colonial-era bungalow lovingly restored with all modern amenities.', 18000000, 'Fort Kochi, Kerala', 'sale', 5, 4, 4200, NULL, 'approved'),
(2, 'Penthouse Suite', 'Ultra-luxury penthouse on the 32nd floor with panoramic city skyline views.', 85000, 'Thiruvananthapuram', 'rent', 3, 3, 2800, NULL, 'approved'),
(2, 'Backwater Estate', 'Exclusive estate on the banks of Ashtamudi Lake. Private boat jetty.', 45000000, 'Kollam, Kerala', 'auction', 6, 5, 6000, NULL, 'approved');

UPDATE properties SET auction_end = DATE_ADD(NOW(), INTERVAL 7 DAY) WHERE type='auction';
